// YOUR NAME (your username)
// Also include any notes to the grader here, if anything is not working, or
// commented out, etc.

public class MovieShelf implements MovieShelfInterface {
	// TODO: everything
}