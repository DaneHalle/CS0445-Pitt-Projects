
/**
* You've seen this one before!
*/
public class ExpressionError extends RuntimeException {
    ExpressionError(String msg) {
        super(msg);
    }
}