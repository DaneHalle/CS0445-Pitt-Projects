/**
 * A station in the streaming radio service.
 */
public interface Station {

}

