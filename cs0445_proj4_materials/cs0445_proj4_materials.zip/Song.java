/**
 * A song, which can be used in the radio streaming service.
 */
public interface Song {

}

