/**
 * A user of the streaming radio service.
 */
public interface User {

}

