{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf600
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 I have done some bonus parts. \
- Defining of names.\
	- How to use it, type \'93java InfixExpressionEvaluator name1=val1 name2=val2\'94  and so on\
	- Note that if  you typed  something like \'93java \'85 name1 = val1\'94, the code would crash  \
- Note about the last method in my code\
	- So this was before I actually knew  what I was doing when it came to going about the process and before I fully understood Postfix notation  but since it is a good 150+ lines of code, I kept it in so  you can see how far off I was getting in my code. \
}